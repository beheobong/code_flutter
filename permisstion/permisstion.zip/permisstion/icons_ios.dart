class SCHIconIOS {
  static final String iSetting = 'assets/icons_ios/ios_settings.png';
  static final String iNotification = 'assets/icons_ios/ios_notification.png';
  static final String iSwitch = 'assets/icons_ios/ios_switch.png';
  static final String iSwitchOff = 'assets/icons_ios/ios_switch_off.png';
  static final String iLocationPrivacy = 'assets/icons_ios/ios_location.png';
  static final String iCameraPrivacy = 'assets/icons_ios/ios_camera.png';
  static final String iPhotosPrivacy = 'assets/icons_ios/ios_photos.png';
  static final String iPrivacy = 'assets/icons_ios/ios_privacy.png';
  static final String icMicrophone = 'assets/icons_ios/microphone_ios.png';
}